from fastapi import FastAPI
from app.routers import ingestion, rag

app = FastAPI(title="FastAPI RAG Backend")

# Include routers
app.include_router(ingestion.router, prefix="/ingest", tags=["Document Ingestion"])
app.include_router(rag.router, prefix="/rag", tags=["RAG & Booking"])
