from fastapi import APIRouter, UploadFile, File, Form
from typing import Optional
from app.db import documents_col
from app.utils.chunking import chunk_text_simple, chunk_text_overlap
from app.utils.embeddings import generate_embedding
from app.utils.storage import save_embedding_to_vector_db

router = APIRouter()

@router.post("/upload")
async def upload_document(
    file: UploadFile = File(...),
    chunk_strategy: Optional[str] = Form("simple")
):
    """Upload PDF or TXT, chunk, generate embeddings, store in DB"""
    # Read file
    contents = await file.read()
    text = contents.decode("utf-8", errors="ignore")  # simple text decode

    # Chunking
    if chunk_strategy == "overlap":
        chunks = chunk_text_overlap(text)
    else:
        chunks = chunk_text_simple(text)

    # Process each chunk
    for i, chunk in enumerate(chunks):
        embedding = generate_embedding(chunk)
        metadata = {"filename": file.filename, "chunk_index": i, "text": chunk}
        save_embedding_to_vector_db(embedding, metadata)
        documents_col.insert_one(metadata)

    return {"status": "success", "chunks": len(chunks)}
