from fastapi import APIRouter, Form
from typing import Optional
from app.utils.embeddings import generate_embedding
from app.utils.storage import query_vector_db
from app.utils.redis_client import save_chat_history, get_chat_history
from app.db import bookings_col

router = APIRouter()

@router.post("/chat")
async def chat(session_id: str = Form(...), query: str = Form(...)):
    """Custom RAG chat with Redis memory"""
    # Generate embedding for query
    query_vec = generate_embedding(query)
    results = query_vector_db(query_vec)
    answer = " ".join([r["metadata"]["text"] for r in results])

    # Save to Redis chat memory
    save_chat_history(session_id, {"role": "user", "content": query})
    save_chat_history(session_id, {"role": "assistant", "content": answer})

    # Return chat history
    history = get_chat_history(session_id)
    return {"answer": answer, "history": history}

@router.post("/book")
async def book_interview(name: str = Form(...), email: str = Form(...),
                         date: str = Form(...), time: str = Form(...)):
    """Store booking info in MongoDB"""
    booking = {"name": name, "email": email, "date": date, "time": time}
    bookings_col.insert_one(booking)
    return {"status": "success", "booking": booking}
