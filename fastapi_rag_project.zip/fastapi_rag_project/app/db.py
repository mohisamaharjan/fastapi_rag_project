from pymongo import MongoClient

# MongoDB connection
client = MongoClient("mongodb://localhost:27017/")
db = client["rag_backend"]

# Collections
documents_col = db["documents"]
bookings_col = db["bookings"]
