import redis
import json
from typing import List, Dict

# Connect to Redis
r = redis.Redis(host='localhost', port=6379, db=0, decode_responses=True)

def save_chat_history(session_id: str, message: Dict):
    """Append a message to a Redis list for a session."""
    r.rpush(session_id, json.dumps(message))

def get_chat_history(session_id: str) -> List[Dict]:
    """Retrieve chat history for a session."""
    messages = r.lrange(session_id, 0, -1)
    return [json.loads(msg) for msg in messages]
