from typing import List
import numpy as np

def generate_embedding(text: str) -> List[float]:
    """
    Dummy embedding generator.
    Replace with real model or API (OpenAI, etc.) if needed.
    """
    # For example, generate a fixed-size vector with random numbers
    np.random.seed(abs(hash(text)) % (2**32))
    return np.random.rand(512).tolist()
