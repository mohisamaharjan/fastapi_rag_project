from typing import List, Dict

# Dummy vector DB (replace with real Pinecone/Qdrant/Milvus later)
VECTOR_DB: List[Dict] = []

def save_embedding_to_vector_db(embedding: List[float], metadata: Dict):
    """Save embedding and metadata to in-memory vector DB."""
    VECTOR_DB.append({"embedding": embedding, "metadata": metadata})

def query_vector_db(query_embedding: List[float], top_k: int = 3) -> List[Dict]:
    """Return top_k nearest embeddings by simple cosine similarity."""
    from numpy import dot
    from numpy.linalg import norm
    results = []
    for entry in VECTOR_DB:
        vec = entry["embedding"]
        score = dot(vec, query_embedding) / (norm(vec) * norm(query_embedding) + 1e-10)
        results.append({"metadata": entry["metadata"], "score": score})
    results.sort(key=lambda x: x["score"], reverse=True)
    return results[:top_k]
